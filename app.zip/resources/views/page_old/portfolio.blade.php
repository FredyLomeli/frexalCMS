@extends('layouts.front')
@section('title', "Servicios - ")
@section('content')
@include('page.servicios')
@endsection
