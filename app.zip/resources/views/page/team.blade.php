@extends('layouts.front')
<!-- contact -->
@include('page.parts.header')
<!-- contact -->
@include('page.parts.team')

@section('styles')
@endsection

@section('content')
    @yield('content_header')
    @yield('content_team')
@endsection

@section('script')
@endsection

